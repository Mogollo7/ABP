


function redirigir(){
    window.location.href = "/2";
}


function generateEmergencyContacts() {
    const container = document.getElementById('contactContainer');
    container.innerHTML = '';
    const numContacts = parseInt(document.querySelector('#num_contacts').value);

    for (let i = 1; i <= numContacts; i++) {
        const contactDiv = document.createElement('div');
        contactDiv.className = 'field';

        const nameInput = document.createElement('input');
        nameInput.type = 'text';
        nameInput.placeholder = `Nombre del Contacto ${i}`;
        nameInput.name = `contact_name_${i}`;
        nameInput.required = true;

        const phoneInput = document.createElement('input');
        phoneInput.type = 'tel';
        phoneInput.placeholder = `Número del Contacto ${i}`;
        phoneInput.name = `contact_phone_${i}`;
        phoneInput.pattern = "[0-9]{3}[0-9]{3}[0-9]{4}";
        phoneInput.required = true;
        contactDiv.style.gap = '8px';

        contactDiv.appendChild(nameInput);
        contactDiv.appendChild(phoneInput);
        container.appendChild(contactDiv);
    }
}

function generateMedicines() {
    const container = document.getElementById('medicineContainer');
    container.innerHTML = '';
    const numMedicines = parseInt(document.querySelector('#num_medicines').value);

    for (let i = 1; i <= numMedicines; i++) {
        const medicineDiv = document.createElement('div');
        medicineDiv.className = 'field';

        const medicineName = document.createElement('input');
        medicineName.type = 'text';
        medicineName.placeholder = `Medicamento ${i}`;
        medicineName.name = `medicine_name_${i}`;
        medicineName.required = true;

        const dosage = document.createElement('input');
        dosage.type = 'number';
        dosage.placeholder = `Dosis ${i}`;
        dosage.name = `medicine_dosage_${i}`;
        dosage.required = true;

        const frequency = document.createElement('input');
        frequency.type = 'number';
        frequency.placeholder = `10 H`;
        frequency.name = `medicine_frequency_${i}`;
        frequency.required = true;

        medicineDiv.appendChild(medicineName);
        medicineDiv.appendChild(dosage);
        medicineDiv.appendChild(frequency);
        container.appendChild(medicineDiv);
        medicineDiv.style.gap = '5px';
        dosage.style.width = '60px';
        frequency.style.width = '50px';



    }
}





const slidePage = document.querySelector(".slidepage");
const firtNextBtn = document.querySelector(".nextBtn");
const prevBtnSec = document.querySelector(".prev-1");
const nextBtnSec = document.querySelector(".next-1");
const nextBtnFour = document.querySelector(".next-3");
const prevBtnFour = document.querySelector(".prev-3"); 
const prevBtnFive = document.querySelector(".prev-4");
const submitBtn = document.querySelector(".submit");
const progressText = document.querySelectorAll(".step p");
const progressCheck = document.querySelectorAll(".step .check");
const bullet = document.querySelectorAll(".step .bullet");
let max = 4;
let current = 1;

function avanzarFormulario() {
        slidePage.style.marginLeft = `-${25 * current}%`;
        bullet[current - 1].classList.add("active");
        progressCheck[current - 1].classList.add("active");
        current += 1;
    
    }


firtNextBtn.addEventListener("click", function() {
    avanzarFormulario();
});

nextBtnSec.addEventListener("click", function() {
    avanzarFormulario();
});

nextBtnFour.addEventListener("click", function() {
    avanzarFormulario();
});




submitBtn.addEventListener("click", function () {
        redirigir();
});




prevBtnSec.addEventListener("click", function(){
    slidePage.style.marginLeft = "0%";
    bullet[current - 2].classList.remove("active");
    progressCheck[current - 2].classList.remove("active");
    current -= 1;
});

prevBtnFour.addEventListener("click", function(){
    slidePage.style.marginLeft = "-25%"; 
    bullet[current - 2].classList.remove("active");
    progressCheck[current - 2].classList.remove("active");
    current -= 1;
});

prevBtnFive.addEventListener("click", function(){
    slidePage.style.marginLeft = "-50%"; 
    bullet[current - 2].classList.remove("active");
    progressCheck[current - 2].classList.remove("active");
    current -= 1;
});




