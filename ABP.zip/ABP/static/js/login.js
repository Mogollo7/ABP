let lock_alt = document.getElementById("lock_alt");
let password = document.getElementById("password");

lock_alt.onclick = function(){
    if(password.type == "password"){
        password.type = "text";
        lock_alt.src = "/static/img/lock-open-alt-solid-24.png";
    }else{
        password.type = "password";
        lock_alt.src = "/static/img/lock-alt-solid-24.png";
    } 
}