const section = document.querySelector("section"),
    overlay = document.querySelector(".overlay"),
    showBtn = document.querySelector(".show-modal"),
    closeBtn = document.querySelector(".close-btn"),
    termsCheckbox = document.querySelector("#terms-checkbox");

showBtn.addEventListener("click", () => section.classList.add("active"));
closeBtn.addEventListener("click", () => {
    if (termsCheckbox.checked) {
        window.location.href = "/3";
    } else {
        alert("Please accept the terms and conditions to proceed.");
    }
});

termsCheckbox.addEventListener("change", () => {
    closeBtn.disabled = !termsCheckbox.checked;
});
const fileInput = document.querySelector("#file");
const uploadIcon = document.querySelector("#upload-icon");

uploadIcon.addEventListener("click", () => {
    fileInput.click(); 
});

fileInput.addEventListener("change", () => {
    const files = fileInput.files;
    if (files.length > 0) {
        alert("Archivo seleccionado: " + files[0].name);
    }
});
