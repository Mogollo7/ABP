from flask import Flask, render_template, request

app = Flask(__name__)

@app.route('/')
def principal():
    
    return render_template("login.html")  

@app.route('/1')
def secun():
    return render_template("sing_up.html")

@app.route('/2')
def tri():
    return render_template("file.html")

@app.route('/3')
def vent():

    return render_template("vent.html")

@app.route('/terms-and-conditions')
def terminos():
    return render_template("terminos.html")

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
